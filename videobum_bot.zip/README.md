# ВидеоБум Бот

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

Телеграм-бот для магазина [videobum.shop](https://videobum.shop)